package FirstP1D1;

public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 50;
		int y = 3;
		System.out.println(x/y);
	}

}
