package FirstP1D1;

public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("   J    a    V     V    a   ");
		 System.out.println("   J   a a    V   V    a a  ");
		 System.out.println("J  J  aaaaa    V V    aaaaa ");
		 System.out.println(" JJ  a     a    V    a     a");
	    
	}

}
