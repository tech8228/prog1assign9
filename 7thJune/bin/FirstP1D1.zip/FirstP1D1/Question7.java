package FirstP1D1;

public class Question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println(" +\"\"\"\"\"+");
	     System.out.println("[| o o |]");
	     System.out.println(" |  ^  | ");
	     System.out.println(" | '-' | ");
	     System.out.println(" +-----+ ");
	     
	}

}
