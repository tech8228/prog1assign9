package d3activity;

import java.util.Scanner;

public class D3Program26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		double val;
		System.out.println("Please input Number ");
		val = scan.nextDouble();
		
		System.out.println("The absolute value is: "+ Math.abs(val));
		
	}

}
