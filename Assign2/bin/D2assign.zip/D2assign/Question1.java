package D2assign;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Double val;
		val = ((25.5*3.5-3.5*3.5)/(40.5 -4.5));
		System.out.println(val);
	}

}
