package D2assign;

public class Question8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int val1, val2, val3, val4;
		
		val1 =  -5 + 8 * 6;
		val2 = (55+9)%9;
		val3 = (int) (20+(-3.5)/8);
		val4 = 5+15/3*2-8%3;
		System.out.println(val1);
		System.out.println(val2);
		System.out.println(val3);
		System.out.println(val4);
	}

}
