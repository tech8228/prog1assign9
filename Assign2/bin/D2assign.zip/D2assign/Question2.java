package D2assign;

public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Double val;
		val = 4.0*(1-(1.0/3)+(1.0/5)-(1.0/7)+(1.0/9)-(1.0/11));
		System.out.println(val);
	}

}
